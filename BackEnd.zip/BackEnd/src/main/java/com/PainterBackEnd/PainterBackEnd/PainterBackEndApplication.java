package com.PainterBackEnd.PainterBackEnd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PainterBackEndApplication {

	public static void main(String[] args) {
		SpringApplication.run(PainterBackEndApplication.class,args);
		System.out.println("hello world");
	}

}
