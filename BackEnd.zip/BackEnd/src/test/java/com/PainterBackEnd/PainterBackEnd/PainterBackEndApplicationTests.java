package com.PainterBackEnd.PainterBackEnd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PainterBackEndApplicationTests {

	@Test
	void contextLoads() {
	}

}
